import subprocess
import re
import webbrowser
from dateutil import parser
import pyautogui
import time
from datetime import datetime

# hàm tự động tham gia cuộc họp
def auto_join_meeting(image_path, wait_time):
    """
    Tự động nhấn nút trên giao diện dựa trên ảnh.
    :param image_path: Đường dẫn đến ảnh của nút cần nhấn (bắt buộc).
    :param wait_time: Số giây cần chờ trước khi tìm nút (bắt buộc).
    """
    print(f"Chờ {wait_time} giây để giao diện ổn định...")
    time.sleep(wait_time)  # Chờ giao diện ổn định

    print(f"Đang tìm nút từ ảnh: {image_path}...")
    try:
        # Tìm nút dựa trên ảnh
        button_location = pyautogui.locateCenterOnScreen(image_path, confidence=0.8)

        if button_location:
            # Điều chỉnh tọa độ cho macOS M1 (Retina Display)
            adjusted_x, adjusted_y = button_location[0] / 2, button_location[1] / 2
            print(f"Tìm thấy nút tại tọa độ: ({adjusted_x}, {adjusted_y}). Đang nhấn nút...")
            pyautogui.click(adjusted_x, adjusted_y)
            print("Đã nhấn nút thành công!")
        else:
            print(f"Không tìm thấy nút. Tiếp tục chạy chương trình...")
    except Exception as e:
        print(f"Lỗi khi tìm và nhấn nút: {str(e)}. Tiếp tục chạy chương trình...")

# Hàm dịch chuỗi thời gian từ tiếng Việt sang tiếng Anh
def translate_time_str(time_str):
    translations = {
        'Thứ Hai': 'Monday',
        'Thứ Ba': 'Tuesday',
        'Thứ Tư': 'Wednesday',
        'Thứ Năm': 'Thursday',
        'Thứ Sáu': 'Friday',
        'Thứ Bảy': 'Saturday',
        'Chủ Nhật': 'Sunday',
        'ngày': '',
        'tháng': '',
        'lúc': '',
        ',': '',
    }
    for vn, en in translations.items():
        time_str = time_str.replace(vn, en)
    return time_str

# Hàm đếm ngược cho đến thời gian bắt đầu cuộc họp
def countdown_to_meeting():
    print("Đang lấy thông tin sự kiện từ lịch...")
    
    # Lấy dữ liệu sự kiện thô từ ứng dụng Lịch
    events_info = get_raw_calendar_events()

    # Phân tích dữ liệu sự kiện
    parsed_events = parse_events(events_info)

    if not parsed_events:
        print("Không có sự kiện nào trong lịch ngày hôm nay. Kết thúc chương trình.")
        return

    # Lấy thời gian bắt đầu của sự kiện đầu tiên
    start_time_str = parsed_events[0]["start"]
    print(f"Thời gian bắt đầu cuộc họp (trước chuẩn hóa): {start_time_str}")

    # Chuẩn hóa chuỗi thời gian
    start_time_str = " ".join(start_time_str.split())  # Loại bỏ khoảng trắng dư thừa
    print(f"Thời gian bắt đầu cuộc họp (sau chuẩn hóa): {start_time_str}")

    try:
        # Chuyển đổi chuỗi thời gian thành đối tượng datetime với định dạng cụ thể
        start_time = datetime.strptime(start_time_str, "%H:%M:%S %A %d %m %Y")
    except Exception as e:
        print(f"Lỗi khi phân tích thời gian bắt đầu: {e}")
        return

    # Tính thời gian còn lại
    current_time = datetime.now()
    time_remaining = (start_time - current_time).total_seconds()

    # Nếu thời gian đã trễ hoặc bằng 0, bỏ qua đếm ngược
    if time_remaining <= 0:
        print("\nBạn đã trễ giờ họp. Bắt đầu chương trình ngay!")
        return  # Thoát khỏi hàm đếm ngược để chạy hàm main()

    # Nếu còn thời gian, bắt đầu đếm ngược
    while time_remaining > 0:
        minutes, seconds = divmod(int(time_remaining), 60)
        print(f"Thời gian còn lại: {minutes} phút {seconds} giây", end="\r")

        # chờ 0.1 giây
        time.sleep(0.1)

        # Cập nhật thời gian còn lại
        current_time = datetime.now()
        time_remaining = (start_time - current_time).total_seconds()

    print("\nĐã đến giờ bắt đầu cuộc họp!")


# Hàm lấy sự kiện từ ứng dụng Lịch bằng AppleScript
def get_raw_calendar_events():
    script = """
    tell application "Calendar"
        set eventList to ""
        set specificDate to (current date) - (time of (current date))
        repeat with aCalendar in calendars
            set eventsList to (every event of aCalendar whose start date ≥ specificDate and start date < (specificDate + 1 * days))
            repeat with anEvent in eventsList
                set eventList to eventList & "Sự kiện: " & (summary of anEvent) & "\n"
                set eventList to eventList & "  Bắt đầu: " & (start date of anEvent as string) & "\n"
                set eventList to eventList & "  Kết thúc: " & (end date of anEvent as string) & "\n"
                set eventList to eventList & "  Địa điểm: " & (location of anEvent) & "\n"
                set eventList to eventList & "  Ghi chú: " & (description of anEvent) & "\n"
                set eventList to eventList & "--------------------------------------------\n"
            end repeat
        end repeat
        return eventList
    end tell
    """
    result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    return result.stdout


# Hàm phân tích cú pháp dữ liệu sự kiện
def parse_events(events_info):
    events = []
    current_event = {}
    
    for line in events_info.splitlines():
        line = line.strip()
        if line.startswith("Sự kiện:"):
            if current_event:
                events.append(current_event)
                current_event = {}
            current_event["summary"] = line.replace("Sự kiện: ", "").strip()
        elif line.startswith("Bắt đầu:"):
            current_event["start"] = translate_time_str(line.replace("Bắt đầu: ", "").strip())
        elif line.startswith("Kết thúc:"):
            current_event["end"] = translate_time_str(line.replace("Kết thúc: ", "").strip())
        elif line.startswith("Địa điểm:"):
            current_event["location"] = line.replace("Địa điểm: ", "").strip()
        elif line.startswith("Ghi chú:"):
            current_event["description"] = line.replace("Ghi chú: ", "").strip()
    
    if current_event:
        events.append(current_event)
    
    return events


# Hàm hiển thị thông tin sự kiện
def display_event(event):
    try:
        start_time = parser.parse(event["start"])
        end_time = parser.parse(event["end"])
        print(f"Sự kiện: {event['summary']}")
        print(f"  Bắt đầu: {start_time}")
        print(f"  Kết thúc: {end_time}")
        print(f"  Địa điểm: {event['location']}")
        print(f"  Ghi chú: {event['description']}")
        print("--------------------------------------------")
    except Exception as e:
        print(f"Lỗi khi xử lý thời gian: {e}")


# Hàm tìm và mở liên kết Microsoft Teams
def open_teams_link(events_info):
    match = re.search(r"https://teams.microsoft.com/[^\s>]+", events_info)
    if match:
        meeting_link = match.group(0)
        print(f"Mở liên kết Microsoft Teams: {meeting_link}")
        webbrowser.open(meeting_link)


# Hàm chính chạy chương trình
def main():
    # Lấy dữ liệu sự kiện thô từ ứng dụng Lịch
    events_info = get_raw_calendar_events()
    
    # Kiểm tra nếu không có sự kiện
    if not events_info.strip():
        print("Không có sự kiện nào trong lịch ngày hôm nay.")
        return
    
    print("Thông tin sự kiện đã lấy được:")
    print(events_info)
    
    # Phân tích dữ liệu sự kiện
    parsed_events = parse_events(events_info)
    
    # Hiển thị thông tin từng sự kiện
    for event in parsed_events:
        display_event(event)
    
    # Tìm và mở liên kết Microsoft Teams nếu có
    open_teams_link(events_info)

    # Tự động tham gia cuộc họp
    auto_join_meeting("turnoffmic.png", 8)
    auto_join_meeting("join.png", 0.5)


# Chạy chương trình
if __name__ == "__main__":
    countdown_to_meeting()
    main()